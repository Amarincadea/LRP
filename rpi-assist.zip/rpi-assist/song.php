<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<body>

<div class="w3-container">


<div class="w3-panel w3-blue">

   <audio controls loop autoplay>
  <source src="http://v7cache.songsjumbo.co/dlmp3/byhM4o/9ixDCkOHmOY/Sundari%20Full%20Song%20Lyrical%20-%20Khaidi%20No%20150%20-%20SongsJumbo.co.mp3?a=byK6OG&b=byK9Rl" type="audio/mp3">
  
Your browser does not support the audio element.
</audio>
  </div>
</div>

</body>
</html>
