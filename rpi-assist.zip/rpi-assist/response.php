<?php
$req=$_POST['q'];


 switch ($req)  {
     case "hello":
     			 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Hi Amar,how was a day');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php

                    break;
      case "fuck you bro": 
      
      	 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Come fuck me');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php
             	break;
             	
       case "sorry": 
      
      	 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Ok please dont repeat again');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php
             	break;

       case "light on": 
      
      	 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('sorry,your home network is out of cloud');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php
             	break;
      
     default:
     ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Sorry Amar no response from server');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php
         }
         
         

 ?>
