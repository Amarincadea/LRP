<?php
$req=$_POST['q'];


 switch ($req)  {
     case "hello buddy":
     			 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Hi bro,how was a day');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php

                    break;
                    
                    
                    
        case "play Sundari song":
        
        ?><br>
     					<div class="w3-panel w3-blue"><br>

		   <audio controls loop autoplay="true">
		  <source src="http://v7cache.songsjumbo.co/dlmp3/byhM4o/9ixDCkOHmOY/Sundari%20Full%20Song%20Lyrical%20-%20Khaidi%20No%20150%20-%20SongsJumbo.co.mp3?a=byK6OG&b=byK9Rl" type="audio/ogg">
		  <source src="http://v7cache.songsjumbo.co/dlmp3/byhM4o/9ixDCkOHmOY/Sundari%20Full%20Song%20Lyrical%20-%20Khaidi%20No%20150%20-%20SongsJumbo.co.mp3?a=byK6OG&b=byK9Rl" type="audio/mpeg">
		Your browser does not support the audio element.
		</audio><br><br>
		  </div>
		</div>
		     		<?	
     			
     			                    break;
     			                    
 	case "play dhivara song":
        
        ?><br>
     					<div class="w3-panel w3-blue"><br>

		   <audio controls loop autoplay="true">
		  <source src="http://v7cache.songsjumbo.co/dlmp3/byhM4o/kUtx1jXRFKo/Dheevara%20Song%20-%20Baahubali%20-%20SongsJumbo.co.mp3?a=byK6OG&b=byK9Rl" type="audio/ogg">
		  <source src="http://v7cache.songsjumbo.co/dlmp3/byhM4o/kUtx1jXRFKo/Dheevara%20Song%20-%20Baahubali%20-%20SongsJumbo.co.mp3?a=byK6OG&b=byK9Rl" type="audio/mpeg">
		Your browser does not support the audio element.
		</audio><br><br>
		  </div>
		</div>
		     		<?	
     			
     			                    break;


       case "hello":
     			 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Hi bro,how was a day');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php

                    break;

       case "tell me about your self":
     			 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Hi, My name is jampi,developed by the CEO of my need they need dot com,his name is Amarnath a 		web developer');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php

                    break;
                    
                    
       case "who is your owner":
     			 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('His name Amarnath a web developer,the CEO of my need they need dot com');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php

                    break;

                    
       case "tell me about yourself":
     			 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Hi, My name is jampi,developed by the CEO of my need they need dot com,his name is Amarnath a web developer');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php

                    break;
          case "who are you":
     			 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Hi, My name is jammpi,developed by the CEO of my need they need dot com,his name is Amarnath a web developer');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php

                    break;




             
             	
       case "sorry": 
      
      	 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Ok please dont repeat again');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php
             	break;

       case "light on": 
      
      	 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('sorry,your home network is out of cloud');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php
             	break;
             	
      case "get out": 
      
      	 ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('ok neechaavu nuvvu chaavu');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
		  close();
	</script>
	
	<?php
             	break;

      
     default:
     ?>
     	<script>
		var msg = new SpeechSynthesisUtterance('Sorry Amar no response from server');
		window.speechSynthesis.speak(msg);
		utterThis.pitch = 2.5;
		  synth.speak(utterThis);
	</script>
	
	<?php
         }
         
         

 ?>


<!DOCTYPE html>
<html>
<title>My Assistant</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-navbar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}
</style>
<body onload="startDictation()">

<!-- Navbar -->
<div class="w3-top">
  <ul class="w3-navbar w3-red w3-card-2 w3-left-align w3-large">
    <li class="w3-hide-medium w3-hide-large w3-opennav w3-right">
      <a class="w3-padding-large w3-hover-white w3-large w3-red" href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    </li>
   
    <li class="w3-hide-small"><a href="#" class="w3-padding-large w3-hover-white">Dashboard</a></li>
    <li class="w3-hide-small"><a href="#" class="w3-padding-large w3-hover-white">About</a></li>
    <li class="w3-hide-small"><a href="#" class="w3-padding-large w3-hover-white">Developer</a></li>
    
  </ul>

  <!-- Navbar on small screens -->
  <div id="navDemo" class="w3-hide w3-hide-large w3-hide-medium">
    <ul class="w3-navbar w3-left-align w3-large w3-black">
      <li><a class="w3-padding-large" href="#">Dashboard</a></li>
      <li><a class="w3-padding-large" href="#">About</a></li>
      <li><a class="w3-padding-large" href="#">Developer</a></li>
      
    </ul>
  </div>
</div>

<!-- Header -->
<header class="w3-container w3-red w3-center w3-padding-128">
  <h1 class="w3-margin w3-jumbo">My Assistant</h1>
  <p class="w3-xlarge">Technology by Amar</p>
  <div class="w3-center" onclick="startDictation()">
      <i class="fa fa-microphone w3-text-white w3-center w3-jumbo"></i>
    </div>
	<div class="w3-card-4 w3-round">
	<br>
		<form class="w3-container" id="labnol" method="POST" action="http://myneedtheyneed.com/amar/rpi-assist/index.php">
			<input class="w3-input" type="text" name="q" id="transcript" placeholder="Speak.....">
		</form>
	<br>	
	</div>
</header>


<div class="w3-container w3-black w3-center w3-opacity w3-padding-64">
    <h1 class="w3-margin w3-xlarge">Beta Version of IOT product by MNTN Inc</h1>
</div>

<!-- Footer -->
<footer class="w3-container w3-padding-64 w3-center w3-opacity">  
 
 <p>Powered by <a href="http://www.w3schools.com/w3css/default.asp" target="_blank">My Need They Need Inc</a></p>
</footer>

<script>
// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>
<!----My Speech Recognition script---->
<script>
  function startDictation() {

    if (window.hasOwnProperty('webkitSpeechRecognition')) {

      var recognition = new webkitSpeechRecognition();

      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.lang = "en-US";
      recognition.start();

      recognition.onresult = function(e) {
        document.getElementById('transcript').value
                                 = e.results[0][0].transcript;
        recognition.stop();
        document.getElementById('labnol').submit();
      };

            recognition.onerror = function(e) {
        recognition.stop();
     
     
      }

    }
  }
</script>
</body>
</html>
